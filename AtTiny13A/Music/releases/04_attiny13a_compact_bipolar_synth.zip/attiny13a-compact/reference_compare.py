#!/usr/bin/env python3
"""Compare AVR emulation vs sample-based GM recording/reference spectra.
Reference samples use a sample-based SoundFont; NOT raw Iowa recordings.
"""
import json
from pathlib import Path
import numpy as np
from scipy.io import wavfile
from scipy.signal import windows
ROOT=Path(__file__).resolve().parent
meta=json.loads((ROOT/'register_demo.json').read_text()); rate,y=wavfile.read(ROOT/'register_demo.wav'); y=y.astype(float)/32768
ss=int(round(meta['noteSeconds']*rate));gs=int(round(meta['gapSeconds']*rate));

def partials(x,fs,midi,start=0.12,duration=0.20,nh=12):
 seg=np.asarray(x[int(round(start*fs)):int(round((start+duration)*fs))],dtype=float)
 seg=seg-np.mean(seg)
 fftsz=2**18;mag=np.abs(np.fft.rfft(seg*np.hanning(len(seg)),n=fftsz))
 freqs=np.fft.rfftfreq(fftsz,1/fs)
 f0=440*2**((midi-69)/12)
 amp=[]
 for k in range(1,nh+1):
  a=k*f0; bw=max(8, a*0.012)
  lo,hi=np.searchsorted(freqs,(a-bw,a+bw)); amp.append(max(1e-12,float(mag[lo:hi].max())))
 amp=np.array(amp)
 db=20*np.log10(amp/max(amp[0],1e-12))
 return np.maximum(db,-70).round(1)

for i,case in enumerate(meta['tests']):
 ins,midi=case['instrument'],case['midi']
 ref_rate,ref=wavfile.read(ROOT/f'reference_{ins}_{midi}.wav')
 ref=ref.astype(float)/32768
 synth=y[i*(ss+gs):i*(ss+gs)+ss]
 for period,(start,duration) in [('early',(0.04,0.12)),('late',(0.23,0.18))]:
  target=partials(ref,ref_rate,midi,start,duration)
  got=partials(synth,rate,midi,start,duration)
  if period=='early':
   print(f'[{ins:6s} {midi:2d}] REAL(SF2) H2-H8 {target[1:8].astype(int).tolist()}')
   print(f'[{ins:6s} {midi:2d}] AVR       H2-H8 {got[1:8].astype(int).tolist()}')
