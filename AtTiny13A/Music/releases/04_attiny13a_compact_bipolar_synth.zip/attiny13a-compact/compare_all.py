#!/usr/bin/env python3
"""Reproducible spectral comparison of two AVR firmware revisions and sample-based GM reference.
Source: TimGM6mb.sf2, GM patches 0 (piano), 24 (nylon guitar), 40 (violin).
It is sample-based, NOT the original Iowa recordings.
"""
import csv, json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.io import wavfile
R=Path(__file__).resolve().parent
metadata=json.loads((R/'register_demo.json').read_text())
fs, baseline=wavfile.read(R/'register_demo_baseline.wav')
fs2, current=wavfile.read(R/'register_demo.wav')
assert fs==fs2
baseline=baseline.astype(float)/32768
current=current.astype(float)/32768
nt=int(round(metadata['noteSeconds']*fs));ng=int(round(metadata['gapSeconds']*fs))

def spectrum(samples,srate,midi,tstart=0.04,duration=0.12):
 x=np.asarray(samples[int(round(tstart*srate)):int(round((tstart+duration)*srate))],dtype=float)
 x=x-np.mean(x)
 nfft=2**18
 power=np.abs(np.fft.rfft(x*np.hanning(len(x)),nfft));f=np.fft.rfftfreq(nfft,1/srate)
 fund=440*2**((midi-69)/12)
 amplitudes=[]
 for h in range(1,9):
  center=h*fund;bw=max(8,center*0.012)
  lo,hi=np.searchsorted(f,[center-bw,center+bw]);amplitudes.append(max(1.e-10,float(power[lo:hi].max())))
 amps=np.array(amplitudes)
 return np.maximum(-65,20*np.log10(amps/amps[0]))

weights=np.array([2,1.6,1.4,1,0.8,0.8,0.5])
rows=[];spectra={}
for i,case in enumerate(metadata['tests']):
 ins=case['instrument'];midi=case['midi'];label=case['label']
 ref_rate, reference=wavfile.read(R/f'reference_{ins}_{midi}.wav')
 reference=reference.astype(float)/32768
 old=baseline[i*(nt+ng):i*(nt+ng)+nt]
 new=current[i*(nt+ng):i*(nt+ng)+nt]
 spectra[(ins,midi)]=xs=[spectrum(s,sr,midi) for s,sr in [(reference,ref_rate),(old,fs),(new,fs)]]
 # Truncate all below -50 dB: low-level spectral noise should not dominate.
 target,prior,after=[np.maximum(s,-50) for s in xs]
 err_old=float(np.average(np.abs(target[1:]-prior[1:]),weights=weights))
 err_new=float(np.average(np.abs(target[1:]-after[1:]),weights=weights))
 row={'instrument':ins,'midi':midi,'name':label, 'mae_old_db':round(err_old,2),'mae_new_db':round(err_new,2),'improvement_db':round(err_old-err_new,2)}
 for h in range(2,9):
  row[f'h{h}_ref']=round(float(xs[0][h-1]),1)
  row[f'h{h}_old']=round(float(xs[1][h-1]),1)
  row[f'h{h}_new']=round(float(xs[2][h-1]),1)
 rows.append(row)
 print(f'{label:22s} MAE {err_old:5.1f} -> {err_new:5.1f} dB (difference {err_old-err_new:+.1f})')
with (R/'comparison_metrics.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
# Graph: rows violin/piano/guitar; columns low/mid/high
notes={'violin':[55,62,74], 'piano':[48,62,81], 'guitar':[43,62,69]}
fig,axes=plt.subplots(3,3,figsize=(13.5,10),sharex=True,sharey=True)
for i,ins in enumerate(notes):
 for j,midi in enumerate(notes[ins]):
  ax=axes[i,j];ref,old,new=spectra[(ins,midi)]
  ax.plot(range(1,9),ref,'o-',color='#333333',lw=2,label='Sampled reference')
  ax.plot(range(1,9),old,'o--',color='#cc7a6b',lw=1.2,label='Previous 917B')
  ax.plot(range(1,9),new,'o-',color='#2979a7',lw=2,label='Revised 1023B')
  name=next(c['label'] for c in metadata['tests'] if c['instrument']==ins and c['midi']==midi)
  ax.set_title(name,fontsize=11)
  ax.set_ylim(-66,7);ax.set_xlim(1,8);ax.set_xticks(range(1,9));ax.grid(alpha=.16)
  if j==0:ax.set_ylabel('Relative harmonic level, dB')
  if i==2:ax.set_xlabel('Harmonic number')
fig.legend(*axes[0,0].get_legend_handles_labels(),loc='upper center',ncol=3,bbox_to_anchor=(0.5,0.965),frameon=False)
fig.suptitle('AVR ATtiny13A vs sample-based instrument reference\nSteady early note (40–160 ms), dB relative to fundamental',fontsize=15,y=.998)
fig.tight_layout(rect=(0,0,1,0.92))
fig.savefig(R/'acoustic_spectrum_comparison.png',dpi=160)
plt.close(fig)
print('Overall avg MAE',round(float(np.mean([r['mae_old_db'] for r in rows])),2), '->',round(float(np.mean([r['mae_new_db'] for r in rows])),2))
for ins in notes:
 items=[r for r in rows if r['instrument']==ins]
 print(ins,'mean',round(float(np.mean([r['mae_old_db'] for r in items])),1),'->',round(float(np.mean([r['mae_new_db'] for r in items])),1))
