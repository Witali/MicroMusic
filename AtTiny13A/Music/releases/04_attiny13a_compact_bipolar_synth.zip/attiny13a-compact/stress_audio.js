/* Exhaustive-ish worst-case emulator test for four voices and all drum modes.
 * Exercises audio-generation ISR paths that occur much more often than music
 * event decoding, and checks the 256-cycle timer deadline.
 */
const fs=require('fs');
const {AVRCore}=require('./avr_core.js');
const cpu=AVRCore.fromHex(fs.readFileSync('synth.hex','utf8'));
cpu.nextDuty();
let allPeak=0,worst=null, sampleMin=255,sampleMax=0;
const notes=(n)=>Math.round(440*Math.pow(2,(n-69)/12)*65536/37500);
for(const mel of [55,62,74])for(const piano of [48,62,81])for(const guitar of [43,62,69])for(const percussion of [0,1,2,3,4]){
  const set=(hi,lo,n)=>{let v=notes(n);cpu.r[hi]=v>>8;cpu.r[lo]=v&255};
  set(5,4,mel);set(9,8,piano);set(13,12,guitar);
  cpu.r[19]=cpu.r[20]=0;cpu.r[21]=percussion;cpu.r[29]=percussion%4;
  cpu.r[22]=255;cpu.r[1]=0;cpu.r[25]=0;
  cpu.r[14]=0xa7;
  cpu.r[24]=0;
  let blockPeak=cpu.maxIRQ;
  for(let j=0;j<256;j++){
    const v=cpu.nextDuty();sampleMin=Math.min(sampleMin,v);sampleMax=Math.max(sampleMax,v);
  }
  if(cpu.maxIRQ>allPeak){allPeak=cpu.maxIRQ;worst={mel,piano,guitar,percussion,peakInfo:cpu.peakInfo};}
}
console.log(JSON.stringify({cycles:cpu.cyc,irqCount:cpu.irqCount,maxIRQ:cpu.maxIRQ,lost:cpu.lost,peak:worst,dutyMin:sampleMin,dutyMax:sampleMax},null,2));
if(cpu.maxIRQ>=256||cpu.lost)process.exitCode=1;
